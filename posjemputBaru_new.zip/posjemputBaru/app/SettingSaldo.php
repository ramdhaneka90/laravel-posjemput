<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SettingSaldo extends Model
{
    protected $table = 'setting';
    public $timestamps = 'false';
}
