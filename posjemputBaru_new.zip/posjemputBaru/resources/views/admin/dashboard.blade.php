@extends('layouts.master-operator')

@section('header','Dashboard')

@section('breadcumb')
<ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Dashboard</a></li>
      </ol>
@endsection

@section('content')
<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Title</h3>

          
        </div>

        <div class="box-body">
          
          <h3>Content Goes Here</h3>  
          
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          
        </div>
        <!-- /.box-footer-->
      </div>
@endsection